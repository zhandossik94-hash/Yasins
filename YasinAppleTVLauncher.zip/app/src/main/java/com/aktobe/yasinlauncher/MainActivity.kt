package com.aktobe.yasinlauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var rvApps: RecyclerView
    private lateinit var adapter: AppsAdapter
    private lateinit var tvWeather: TextView
    private lateinit var tvHeroTitle: TextView
    private lateinit var tvHeroDate: TextView

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private val prefs by lazy { getSharedPreferences("tvos_prefs", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvApps = findViewById(R.id.rvApps)
        tvWeather = findViewById(R.id.tvWeather)
        tvHeroTitle = findViewById(R.id.tvHeroTitle)
        tvHeroDate = findViewById(R.id.tvHeroDate)

        setupTopControls()
        setupGrid()
        updateDateText()
        loadApps()
        fetchAktobeWeather()
    }

    override fun onResume() {
        super.onResume()
        updateDateText()
        loadApps()
    }

    private fun updateDateText() {
        val sdf = SimpleDateFormat("EEEE, d MMMM", Locale("ru"))
        val formatted = sdf.format(Date()).replaceFirstChar { it.uppercase() }
        tvHeroDate.text = "$formatted • Оптимизированный режим"
    }

    private fun setupTopControls() {
        val btnSettings = findViewById<TextView>(R.id.btnSystemSettings)
        val btnYouTube = findViewById<TextView>(R.id.btnQuickYouTube)
        val btnInputs = findViewById<TextView>(R.id.btnQuickInputs)

        val chipFocusListener = View.OnFocusChangeListener { v, hasFocus ->
            val tv = v as TextView
            tv.setTextColor(if (hasFocus) Color.parseColor("#0F172A") else Color.WHITE)
            v.animate().scaleX(if (hasFocus) 1.07f else 1.0f)
                .scaleY(if (hasFocus) 1.07f else 1.0f)
                .setDuration(130).start()
        }

        btnSettings.onFocusChangeListener = chipFocusListener
        btnYouTube.onFocusChangeListener = chipFocusListener
        btnInputs.onFocusChangeListener = chipFocusListener

        btnSettings.setOnClickListener {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }

        btnYouTube.setOnClickListener {
            launchYouTubeClient()
        }

        btnInputs.setOnClickListener {
            openTvInputs()
        }
    }

    private fun launchYouTubeClient() {
        val candidates = listOf(
            "com.liskovsoft.smarttubetv.beta",
            "com.liskovsoft.smarttubetv",
            "com.google.android.youtube.tv"
        )
        for (pkg in candidates) {
            val intent = packageManager.getLeanbackLaunchIntentForPackage(pkg)
                ?: packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                startActivity(intent)
                return
            }
        }
        Toast.makeText(this, "YouTube / SmartTube не установлен", Toast.LENGTH_SHORT).show()
    }

    private fun openTvInputs() {
        try {
            val tvInputIntent = Intent("android.media.tv.action.SETUP_INPUTS")
            startActivity(tvInputIntent)
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Используйте кнопку Source на пульте YASIN", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupGrid() {
        rvApps.layoutManager = GridLayoutManager(this, 5)
        adapter = AppsAdapter(
            apps = emptyList(),
            onAppClick = { app -> launchApp(app) },
            onAppLongClick = { app -> showAppOptionsDialog(app) },
            onAppFocused = { app ->
                tvHeroTitle.text = app.label
            }
        )
        rvApps.adapter = adapter
    }

    private fun loadApps() {
        scope.launch(Dispatchers.IO) {
            val pm = packageManager
            val hiddenPackages = prefs.getStringSet("hidden_pkgs", emptySet()) ?: emptySet()
            val appMap = LinkedHashMap<String, AppInfo>()

            // 1. Collect Leanback TV apps first (to get wide 16:9 banners)
            val leanbackIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            }
            val leanbackList = pm.queryIntentActivities(leanbackIntent, 0)
            for (ri in leanbackList) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || hiddenPackages.contains(pkg)) continue
                val banner = try {
                    ri.activityInfo.loadBanner(pm) ?: pm.getApplicationBanner(pkg)
                } catch (_: Exception) { null }
                appMap[pkg] = AppInfo(
                    label = ri.loadLabel(pm).toString(),
                    packageName = pkg,
                    icon = ri.loadIcon(pm),
                    banner = banner,
                    isLeanback = true
                )
            }

            // 2. Collect standard Android apps (sideloaded APKs)
            val mainIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val standardList = pm.queryIntentActivities(mainIntent, 0)
            for (ri in standardList) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || hiddenPackages.contains(pkg) || appMap.containsKey(pkg)) continue
                appMap[pkg] = AppInfo(
                    label = ri.loadLabel(pm).toString(),
                    packageName = pkg,
                    icon = ri.loadIcon(pm),
                    banner = null,
                    isLeanback = false
                )
            }

            val sortedApps = appMap.values.sortedBy { it.label.lowercase(Locale.getDefault()) }
            withContext(Dispatchers.Main) {
                adapter.updateList(sortedApps)
                if (sortedApps.isNotEmpty() && rvApps.focusedChild == null) {
                    rvApps.post {
                        rvApps.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
                    }
                }
            }
        }
    }

    private fun launchApp(app: AppInfo) {
        val intent = packageManager.getLeanbackLaunchIntentForPackage(app.packageName)
            ?: packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } else {
            Toast.makeText(this, "Не удалось открыть ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAppOptionsDialog(app: AppInfo) {
        val options = arrayOf(
            "Открыть",
            "О приложении (Очистить кэш / Остановить)",
            "Скрыть с главного экрана",
            "Показать все скрытые приложения"
        )
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> launchApp(app)
                    1 -> {
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.parse("package:${app.packageName}")
                        }
                        startActivity(intent)
                    }
                    2 -> {
                        val set = (prefs.getStringSet("hidden_pkgs", emptySet()) ?: emptySet()).toMutableSet()
                        set.add(app.packageName)
                        prefs.edit().putStringSet("hidden_pkgs", set).apply()
                        loadApps()
                    }
                    3 -> {
                        prefs.edit().remove("hidden_pkgs").apply()
                        loadApps()
                        Toast.makeText(this, "Скрытые приложения возвращены", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    // Lightweight weather fetcher for Aktobe (50.2839, 57.1670) via Open-Meteo (No API key needed)
    private fun fetchAktobeWeather() {
        scope.launch(Dispatchers.IO) {
            try {
                val url = URL("https://api.open-meteo.com/v1/forecast?latitude=50.2839&longitude=57.1670&current_weather=true")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val current = json.getJSONObject("current_weather")
                val temp = Math.round(current.getDouble("temperature"))
                val sign = if (temp > 0) "+" else ""
                withContext(Dispatchers.Main) {
                    tvWeather.text = "Актюбинск • $sign$temp°C"
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) {
                    tvWeather.text = "Актюбинск"
                }
            }
        }
    }

    // Prevent Back button from exiting the launcher
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            rvApps.smoothScrollToPosition(0)
            rvApps.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
