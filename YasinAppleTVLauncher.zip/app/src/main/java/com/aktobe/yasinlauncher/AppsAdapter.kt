package com.aktobe.yasinlauncher

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppsAdapter(
    private var apps: List<AppInfo>,
    private val onAppClick: (AppInfo) -> Unit,
    private val onAppLongClick: (AppInfo) -> Unit,
    private val onAppFocused: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppsAdapter.AppViewHolder>() {

    class AppViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tileCard: FrameLayout = view.findViewById(R.id.tileCard)
        val ivBanner: ImageView = view.findViewById(R.id.ivAppBanner)
        val ivIcon: ImageView = view.findViewById(R.id.ivAppIcon)
        val tvName: TextView = view.findViewById(R.id.tvAppName)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_tile, parent, false)
        return AppViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        val app = apps[position]
        holder.tvName.text = app.label

        if (app.banner != null) {
            holder.ivBanner.visibility = View.VISIBLE
            holder.ivBanner.setImageDrawable(app.banner)
            holder.ivIcon.visibility = View.GONE
        } else {
            holder.ivBanner.visibility = View.GONE
            holder.ivIcon.visibility = View.VISIBLE
            holder.ivIcon.setImageDrawable(app.icon)
        }

        // Apple TV tactile zoom animation on D-Pad focus
        holder.itemView.setOnFocusChangeListener { v, hasFocus ->
            val scale = if (hasFocus) 1.11f else 1.0f
            val elevation = if (hasFocus) 18f else 4f
            v.animate()
                .scaleX(scale)
                .scaleY(scale)
                .setDuration(150)
                .setInterpolator(DecelerateInterpolator())
                .start()
            holder.tileCard.elevation = elevation
            holder.tvName.setTextColor(
                if (hasFocus) Color.WHITE else Color.parseColor("#99FFFFFF")
            )
            if (hasFocus) {
                onAppFocused(app)
            }
        }

        holder.itemView.setOnClickListener {
            onAppClick(app)
        }

        holder.itemView.setOnLongClickListener {
            onAppLongClick(app)
            true
        }
    }

    override fun getItemCount(): Int = apps.size

    fun updateList(newApps: List<AppInfo>) {
        apps = newApps
        notifyDataSetChanged()
    }
}
