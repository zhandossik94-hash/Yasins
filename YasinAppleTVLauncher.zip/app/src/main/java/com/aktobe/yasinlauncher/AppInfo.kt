package com.aktobe.yasinlauncher

import android.graphics.drawable.Drawable

data class AppInfo(
    val label: String,
    val packageName: String,
    val icon: Drawable,
    val banner: Drawable?,
    val isLeanback: Boolean
)
